---
name: Battle Royale Game Architecture
description: Key decisions and defensive patterns for the 3D Free Fire browser game in artifacts/3d-game
---

## Always use fallbacks for gameData arrays

```tsx
const char   = CHARACTERS[selectedChar] ?? CHARACTERS[0];   // never undefined
const weapon = WEAPONS[selectedWeapon]  ?? WEAPONS[0];
const mode   = MODES.find((m) => m.id === gameMode) ?? MODES[0];
```

**Why:** Old user accounts stored in localStorage may lack `selectedChar`, `selectedWeapon`, or `gameMode` fields — and guests start with partial data. Crashing with `Cannot read properties of undefined` was the recurring bug.

**How to apply:** Any component that reads from CHARACTERS/WEAPONS/MODES by index or .find() must always have a `?? fallback`.

## Username-based UI must use optional chaining

```tsx
{(username?.[0] ?? '?').toUpperCase()}  // safe even for empty string or undefined
```

**Why:** Guest usernames are generated as `Invité_XXXX` but the prop can be empty or undefined during the initial render before localStorage is read.

## UserAccount interface — always use ?? for new fields

New fields like `diamonds` and `gameMode` may not exist in accounts saved before the feature was added:
```ts
user.diamonds ?? 0
user.gameMode ?? 'quick'
```

## Stack

- React + Vite (artifact: `artifacts/3d-game`, port from `PORT` env var)
- @react-three/fiber + @react-three/drei for 3D
- All UI in French
- CSS in `src/index.css` (single file, no CSS modules)
- gameData.ts exports: CHARACTERS, WEAPONS, MODES, COSMETICS, WEAPON_CATEGORIES, DEFAULT_OUTFIT, GOLD_PER_KILL, GOLD_WIN_BONUS, GOLD_BR_WIN

## Screen routing in App.tsx

`screen` state drives: login → lobby → character/shop/wardrobe/settings/friends/mode → game

## ModeScreen CSS classes

Uses `mode-select-card`, `mode-select-card--active`, `msc-name`, `msc-desc`, `msc-enemies`, `msc-badge`
(NOT `mode-card` — that was the old name)
